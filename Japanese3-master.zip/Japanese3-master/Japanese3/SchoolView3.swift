//
//  SchoolView3.swift
//  Japanese3
//
//  Created by 박지원 on 26/01/2018.
//  Copyright © 2018 Bram Williams. All rights reserved.
//

import Cocoa

class SchoolView3: NSViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do view setup here.
    }
    
}
