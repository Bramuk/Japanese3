//
//  ViewController.swift
//  Japanese3
//
//  Created by Bram Williams on 2018/01/16.
//  Copyright © 2018 Bram Williams. All rights reserved.
//

import Cocoa

class ViewController: NSViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override var representedObject: Any? {
        didSet {
        // Update the view, if already loaded.
        }
    }

   
    @IBOutlet weak var SchoolButton: NSButton!
    
}

