//
//  AppDelegate.swift
//  Japanese3
//
//  Created by Bram Williams on 2018/01/16.
//  Copyright © 2018 Bram Williams. All rights reserved.
//

import Cocoa

@NSApplicationMain
class AppDelegate: NSObject, NSApplicationDelegate {



    func applicationDidFinishLaunching(_ aNotification: Notification) {
        // Insert code here to initialize your application
    }

    func applicationWillTerminate(_ aNotification: Notification) {
        // Insert code here to tear down your application
    }


}

